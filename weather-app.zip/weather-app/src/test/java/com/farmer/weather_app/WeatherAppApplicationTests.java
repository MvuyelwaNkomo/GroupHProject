package com.farmer.weather_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
